# React UI Assignment

This repository contains two reusable React components built using **React**, **TypeScript**, **TailwindCSS**, and **Storybook**.

## 🚀 Features
- InputField Component with variants, sizes, states
- DataTable Component with sorting, selection, loading, and empty states
- Storybook for documentation
- TailwindCSS for modern styling
- Vitest + React Testing Library for testing
- Chromatic deployment configured

## 🛠️ Setup
```bash
npm install
npm run dev
```

## 📘 Storybook
```bash
npm run storybook
```

## 🚀 Deploy Storybook to Chromatic
1. Sign up at [https://www.chromatic.com/](https://www.chromatic.com/)
2. Create a new project and get your **Project Token**
3. Run:
```bash
npm run chromatic -- --project-token=<YOUR_PROJECT_TOKEN>
```
4. You'll get a **hosted Storybook link** instantly!

## 📂 Folder Structure
```
src/
  components/
    InputField.tsx
    DataTable.tsx
  stories/
    InputField.stories.tsx
    DataTable.stories.tsx
```

## 🧪 Testing
```bash
npm run test
```

## 📝 License
MIT
