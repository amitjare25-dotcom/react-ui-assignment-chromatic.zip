import type { Meta, StoryObj } from '@storybook/react';
import { DataTable } from '../components/DataTable';

const meta: Meta<typeof DataTable> = {
  title: 'Components/DataTable',
  component: DataTable,
};
export default meta;
type Story = StoryObj<typeof DataTable>;

interface RowData {
  id: number;
  name: string;
  age: number;
}

const sampleData: RowData[] = [
  { id: 1, name: 'Amit', age: 22 },
  { id: 2, name: 'Ravi', age: 25 },
  { id: 3, name: 'Priya', age: 28 },
];

export const Default: Story = {
  args: {
    data: sampleData,
    columns: [
      { key: 'id', title: 'ID', dataIndex: 'id', sortable: true },
      { key: 'name', title: 'Name', dataIndex: 'name', sortable: true },
      { key: 'age', title: 'Age', dataIndex: 'age', sortable: true },
    ],
    selectable: true,
  },
};
