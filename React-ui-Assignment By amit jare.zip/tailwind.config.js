module.exports = {
  content: ["./src/**/*.{ts,tsx,js,jsx}", "./.storybook/**/*.{ts,tsx,js,jsx}"],
  theme: { extend: {} },
  plugins: [],
};