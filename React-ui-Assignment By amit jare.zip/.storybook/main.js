module.exports = {
  stories: ["../src/**/*.stories.@(ts|tsx|js|jsx)"],
  framework: "@storybook/react",
  typescript: { reactDocgen: "react-docgen" },
};