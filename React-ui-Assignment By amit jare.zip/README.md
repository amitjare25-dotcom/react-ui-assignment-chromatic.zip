# React UI Components Assignment

## 🚀 Features
- React + TypeScript + Tailwind
- Storybook documentation
- InputField with variants, validation, helper text
- DataTable with sorting, selection, loading, empty state
- Basic tests using Vitest + React Testing Library

## 🛠 Setup
```bash
npm install
npm run start            # Start Storybook
npm run build-storybook  # Build static Storybook
npm run test             # Run tests
```

## 📦 Deploy Storybook
Use Chromatic:
```bash
npx chromatic --project-token <your-token> --exit-once-uploaded
```