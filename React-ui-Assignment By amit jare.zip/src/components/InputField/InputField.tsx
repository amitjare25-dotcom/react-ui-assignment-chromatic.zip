import React, { useState } from "react";

export interface InputFieldProps {
  value?: string;
  onChange?: (e: React.ChangeEvent<HTMLInputElement>) => void;
  label?: string;
  placeholder?: string;
  helperText?: string;
  errorMessage?: string;
  disabled?: boolean;
  invalid?: boolean;
  variant?: "filled" | "outlined" | "ghost";
  size?: "sm" | "md" | "lg";
  type?: string;
  showClear?: boolean;
  showPasswordToggle?: boolean;
  className?: string;
  id?: string;
}

const sizeClasses: Record<string, string> = {
  sm: "px-2 py-1 text-sm",
  md: "px-3 py-2 text-base",
  lg: "px-4 py-3 text-lg",
};

const variantBase: Record<string, string> = {
  filled: "bg-gray-100 border border-transparent rounded-md",
  outlined: "bg-white border border-gray-300 rounded-md",
  ghost: "bg-transparent border border-transparent rounded-md",
};

const InputField: React.FC<InputFieldProps> = ({
  value,
  onChange,
  label,
  placeholder,
  helperText,
  errorMessage,
  disabled,
  invalid,
  variant = "outlined",
  size = "md",
  type = "text",
  showClear = true,
  showPasswordToggle = false,
  className = "",
  id,
}) => {
  const [internalType, setInternalType] = useState<string>(type);
  const hasError = !!errorMessage || invalid;
  const idToUse = id ?? `input-${Math.random().toString(36).slice(2, 9)}`;

  return (
    <div className={`w-full ${className}`}>
      {label && <label htmlFor={idToUse} className="block text-sm font-medium text-gray-700 mb-1">{label}</label>}

      <div className="relative">
        <input
          id={idToUse}
          aria-invalid={hasError}
          aria-describedby={helperText || errorMessage ? `${idToUse}-hint` : undefined}
          className={[
            "w-full focus:outline-none focus:ring-2 focus:ring-indigo-500",
            variantBase[variant],
            sizeClasses[size],
            disabled ? "opacity-50 cursor-not-allowed" : "",
            hasError ? "border-red-500 ring-red-200" : "",
          ].join(" ")}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          disabled={disabled}
          type={internalType}
        />

        <div className="absolute inset-y-0 right-0 pr-2 flex items-center space-x-1">
          {showClear && !disabled && value ? (
            <button
              aria-label="Clear input"
              type="button"
              onClick={() => onChange?.({ target: { value: "" } } as any)}
              className="p-1 rounded hover:bg-gray-200"
            >✕</button>
          ) : null}

          {showPasswordToggle && type === "password" ? (
            <button
              aria-label={internalType === "password" ? "Show password" : "Hide password"}
              type="button"
              onClick={() => setInternalType((t) => (t === "password" ? "text" : "password"))}
              className="p-1 rounded hover:bg-gray-200"
            >
              {internalType === "password" ? "👁" : "🙈"}
            </button>
          ) : null}
        </div>
      </div>

      <div className="mt-1">
        {hasError ? (
          <p id={`${idToUse}-hint`} role="alert" className="text-sm text-red-600">{errorMessage}</p>
        ) : helperText ? (
          <p id={`${idToUse}-hint`} className="text-sm text-gray-500">{helperText}</p>
        ) : null}
      </div>
    </div>
  );
};

export default InputField;