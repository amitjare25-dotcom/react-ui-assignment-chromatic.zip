import React, { useMemo, useState } from "react";

export interface Column<T> {
  key: string;
  title: string;
  dataIndex: keyof T;
  sortable?: boolean;
  width?: string | number;
  render?: (value: any, row: T, idx: number) => React.ReactNode;
}

export interface DataTableProps<T> {
  data: T[];
  columns: Column<T>[];
  loading?: boolean;
  selectable?: boolean;
  onRowSelect?: (selectedRows: T[]) => void;
  emptyComponent?: React.ReactNode;
  pageSize?: number;
  className?: string;
}

type SortState = { key: string | null; direction: "asc" | "desc" | null };

export function DataTable<T extends Record<string, any>>({
  data,
  columns,
  loading = false,
  selectable = false,
  onRowSelect,
  emptyComponent,
  pageSize = 50,
  className = "",
}: DataTableProps<T>) {
  const [selectedKeys, setSelectedKeys] = useState<Set<number>>(new Set());
  const [sort, setSort] = useState<SortState>({ key: null, direction: null });

  const handleSort = (col: Column<T>) => {
    if (!col.sortable) return;
    setSort((s) => {
      if (s.key !== col.key) return { key: col.key, direction: "asc" };
      if (s.direction === "asc") return { key: col.key, direction: "desc" };
      return { key: null, direction: null };
    });
  };

  const sortedData = useMemo(() => {
    if (!sort.key || !sort.direction) return data;
    const col = columns.find((c) => c.key === sort.key);
    if (!col) return data;

    const idx = col.dataIndex as string;
    const sorted = [...data].sort((a, b) => {
      const A = a[idx];
      const B = b[idx];
      if (A === B) return 0;
      if (A == null) return -1;
      if (B == null) return 1;
      if (typeof A === "number" && typeof B === "number") {
        return sort.direction === "asc" ? A - B : B - A;
      }
      return sort.direction === "asc"
        ? String(A).localeCompare(String(B))
        : String(B).localeCompare(String(A));
    });
    return sorted;
  }, [data, sort, columns]);

  const toggleSelection = (rowIndex: number) => {
    setSelectedKeys((prev) => {
      const next = new Set(prev);
      if (next.has(rowIndex)) next.delete(rowIndex);
      else next.add(rowIndex);
      onRowSelect?.([...next].map((i) => sortedData[i]));
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedKeys.size === sortedData.length) {
      setSelectedKeys(new Set());
      onRowSelect?.([]);
    } else {
      const all = new Set<number>(sortedData.map((_, idx) => idx));
      setSelectedKeys(all);
      onRowSelect?.([...all].map((i) => sortedData[i]));
    }
  };

  return (
    <div className={`w-full overflow-x-auto ${className}`}>
      <table className="min-w-full divide-y divide-gray-200" role="table">
        <thead className="bg-gray-50">
          <tr>
            {selectable && (
              <th className="px-4 py-2 text-left">
                <input
                  aria-label="Select all rows"
                  type="checkbox"
                  checked={selectedKeys.size === sortedData.length && sortedData.length > 0}
                  onChange={toggleSelectAll}
                />
              </th>
            )}
            {columns.map((col) => (
              <th
                key={col.key}
                className="px-4 py-2 text-left text-sm font-medium text-gray-700 select-none"
                onClick={() => handleSort(col)}
                role={col.sortable ? "button" : undefined}
                aria-sort={sort.key === col.key ? (sort.direction === "asc" ? "ascending" : "descending") : "none"}
              >
                <div className="flex items-center gap-2">
                  <span>{col.title}</span>
                  {col.sortable && (
                    <span className="text-xs text-gray-400">
                      {sort.key === col.key ? (sort.direction === "asc" ? "▲" : "▼") : "⇅"}
                    </span>
                  )}
                </div>
              </th>
            ))}
          </tr>
        </thead>

        <tbody className="bg-white divide-y divide-gray-200">
          {loading ? (
            <tr>
              <td colSpan={columns.length + (selectable ? 1 : 0)} className="px-4 py-8 text-center">
                Loading...
              </td>
            </tr>
          ) : sortedData.length === 0 ? (
            <tr>
              <td colSpan={columns.length + (selectable ? 1 : 0)} className="px-4 py-8 text-center">
                {emptyComponent ?? <span className="text-gray-500">No data</span>}
              </td>
            </tr>
          ) : (
            sortedData.map((row, rowIndex) => (
              <tr
                key={rowIndex}
                className={`hover:bg-gray-50 ${selectedKeys.has(rowIndex) ? "bg-indigo-50" : ""}`}
                role="row"
              >
                {selectable && (
                  <td className="px-4 py-2">
                    <input
                      aria-label={`Select row ${rowIndex + 1}`}
                      type="checkbox"
                      checked={selectedKeys.has(rowIndex)}
                      onChange={() => toggleSelection(rowIndex)}
                    />
                  </td>
                )}
                {columns.map((col) => (
                  <td key={col.key} className="px-4 py-2 whitespace-nowrap text-sm text-gray-700">
                    {col.render ? col.render(row[col.dataIndex], row, rowIndex) : String(row[col.dataIndex] ?? "")}
                  </td>
                ))}
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
}

export default DataTable;